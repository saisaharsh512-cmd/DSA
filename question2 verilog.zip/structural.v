//original
module original_structural(
    input x,
    input y,
    input z,
    output F
);

wire x_not;
wire y_not;
wire z_not;

wire term1;
wire term2;
wire term3;

not(x_not,x);
not(y_not,y);
not(z_not,z);

and(term1,x_not,y_not);
and(term2,x_not,z);
and(term3,x_not,z_not);

or(F,term1,term2,term3);
endmodule

//simplified
module simplified_structural(
  input x,
    input y,
    input z,
    output F
);

not(F,x);
endmodule