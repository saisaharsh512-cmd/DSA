`timescale 1ns/1ps

module testbench;
reg X;
reg Y;
reg Z;

wire F_original;
wire F_simplified;

original_structural original(
    .x(X),
    .y(Y),
    .z(Z),
    .F(F_original_s)
);

simplified_structural simplified(
    .x(X),
    .y(Y),
    .z(Z),
    .F(F_simplified_s)
);
original_behavioral original_b(
    .x(X),
    .y(Y),
    .z(Z),
    .F(F_original_b)
);

simplified_behavioral simplified_b(
    .x(X),
    .y(Y),
    .z(Z),
    .F(F_simplified_b)
);
original_dataflow original_d(
    .x(X),
    .y(Y),
    .z(Z),
    .F(F_original_d)
);

simplified_dataflow simplified_d(
    .x(X),
    .y(Y),
    .z(Z),
    .F(F_simplified_d)
);

initial begin
    $display("X Y Z |  S_structural  |  O_structural  |  S_behavioral  |  O_behavioral  |  S_dataflow    |  O_dataflow    |");
    $display("------------------------------------------------------------------------------------------------------------------");

    X=0;Y=0;Z=0; #10;
    $display("%b %b %b |        %b       |        %b       |        %b       |        %b       |        %b       |        %b       |",X,Y,Z,F_simplified_s,F_original_s,F_simplified_b,F_original_b,F_simplified_d,F_original_d);

     X=0;Y=0;Z=1; #10;
    $display("%b %b %b |        %b       |        %b       |        %b       |        %b       |        %b       |        %b       |",X,Y,Z,F_simplified_s,F_original_s,F_simplified_b,F_original_b,F_simplified_d,F_original_d);

    
     X=0;Y=1;Z=0; #10;
   $display("%b %b %b |        %b       |        %b       |        %b       |        %b       |        %b       |        %b       |",X,Y,Z,F_simplified_s,F_original_s,F_simplified_b,F_original_b,F_simplified_d,F_original_d);

     X=0;Y=1;Z=1; #10;
    $display("%b %b %b |        %b       |        %b       |        %b       |        %b       |        %b       |        %b       |",X,Y,Z,F_simplified_s,F_original_s,F_simplified_b,F_original_b,F_simplified_d,F_original_d);

     X=1;Y=0;Z=0; #10;
    $display("%b %b %b |        %b       |        %b       |        %b       |        %b       |        %b       |        %b       |",X,Y,Z,F_simplified_s,F_original_s,F_simplified_b,F_original_b,F_simplified_d,F_original_d);

     X=1;Y=0;Z=1; #10;
    $display("%b %b %b |        %b       |        %b       |        %b       |        %b       |        %b       |        %b       |",X,Y,Z,F_simplified_s,F_original_s,F_simplified_b,F_original_b,F_simplified_d,F_original_d);

    
     X=1;Y=1;Z=0; #10;
   $display("%b %b %b |        %b       |        %b       |        %b       |        %b       |        %b       |        %b       |",X,Y,Z,F_simplified_s,F_original_s,F_simplified_b,F_original_b,F_simplified_d,F_original_d);

    
     X=1;Y=1;Z=1; #10;
   $display("%b %b %b |        %b       |        %b       |        %b       |        %b       |        %b       |        %b       |",X,Y,Z,F_simplified_s,F_original_s,F_simplified_b,F_original_b,F_simplified_d,F_original_d);

    
    $finish;
end
endmodule
//iverilog -o simulation structural.v behavioral.v dataflow.v testbench.v
//vvp simulation 