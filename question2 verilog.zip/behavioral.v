//original
module original_behavioral(
    input x,
    input y,
    input z,
    output reg F
);

always@(*) begin
    F=(~x&~y)|(~x&z)|(~x&~z);
end
endmodule

//simplified
module simplified_behavioral(
    input x,
    input y,
    input z,
    output reg F
);

always@(*) begin
    F=~x;
end
endmodule

