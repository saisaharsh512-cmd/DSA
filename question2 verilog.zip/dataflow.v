//original 
module original_dataflow(
    input x,
    input y,
    input z,
    output F
);

assign F=(~x&~y)|(~x&z)|(~x&~z);
endmodule

//simplified

module simplified_dataflow(
 input x,
    input y,
    input z,
    output F
);

assign F=~x;
endmodule